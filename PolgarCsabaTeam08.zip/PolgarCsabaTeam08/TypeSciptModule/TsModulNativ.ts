export { };

function Rng(alsoHatar: number, felsoHatar: number): number {
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;

}

function TombGenerator(meret: number, alsoHatar: number, felsoHatar: number): Array<number> {

    let generaltTomb: Array<number> = [];
    for (let i = 0; i < meret; i++) {
        generaltTomb.push(Rng(alsoHatar, felsoHatar));
    }
    return generaltTomb;
}

function Duplazo(VizsgaltTomb: Array<number>): Array<number> {

    let ujGeneraltTomb: Array<number> = [];
    for (let i = 0; i < VizsgaltTomb.length; i++) {
        ujGeneraltTomb.push(VizsgaltTomb[i] * 2)


    }
    return ujGeneraltTomb;

}

function PrimekSzama(VizsgaltTomb: Array<number>): number {

    let primMennyiseg: number = 0;
    let oszto: number = 0;
    for (let i = 0; i < VizsgaltTomb.length; i++) {

        for (let j = 0; i <= VizsgaltTomb[j]; j++) {

            if (VizsgaltTomb[j] % j == 0) {
                oszto++;
            }
        }
        if (oszto == 2) {

            primMennyiseg++;

        }
    }

    return primMennyiseg;
}

function EgyediElemek(VizsgaltTomb: Array<number>):Array<number> {

    let ujGeneraltTomb: Array<number> = [];

    for(let i=0;i<VizsgaltTomb.length;i++)
    {

        for(let j=0;j<ujGeneraltTomb.length;j++)
        {
            if(VizsgaltTomb[i]==ujGeneraltTomb[j])
                {

                    ujGeneraltTomb.push(VizsgaltTomb[i])

                }
        }
    }
return ujGeneraltTomb;
}

