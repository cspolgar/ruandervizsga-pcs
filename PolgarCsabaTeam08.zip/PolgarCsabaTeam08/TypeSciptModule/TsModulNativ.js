"use strict";
exports.__esModule = true;
function Rng(alsoHatar, felsoHatar) {
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
}
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var generaltTomb = [];
    for (var i = 0; i < meret; i++) {
        generaltTomb.push(Rng(alsoHatar, felsoHatar));
    }
    return generaltTomb;
}
function Duplazo(VizsgaltTomb) {
    var ujGeneraltTomb = [];
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        ujGeneraltTomb.push(VizsgaltTomb[i] * 2);
    }
    return ujGeneraltTomb;
}
function PrimekSzama(VizsgaltTomb) {
    var primMennyiseg = 0;
    var oszto = 0;
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        for (var j = 0; i <= VizsgaltTomb[j]; j++) {
            if (VizsgaltTomb[j] % j == 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            primMennyiseg++;
        }
    }
    return primMennyiseg;
}
function EgyediElemek(VizsgaltTomb) {
    var ujGeneraltTomb = [];
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        for (var j = 0; j < ujGeneraltTomb.length; j++) {
            if (VizsgaltTomb[i] == ujGeneraltTomb[j]) {
                ujGeneraltTomb.push(VizsgaltTomb[i]);
            }
        }
    }
    return ujGeneraltTomb;
}
